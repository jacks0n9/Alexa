/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-u17
 */

#ifndef ti_mas_eco__
#define ti_mas_eco__



#endif /* ti_mas_eco__ */ 
